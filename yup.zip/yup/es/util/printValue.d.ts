export default function printValue(value: any, quoteStrings?: boolean): any;
