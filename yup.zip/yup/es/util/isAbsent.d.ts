declare const _default: (value: any) => value is null | undefined;
export default _default;
