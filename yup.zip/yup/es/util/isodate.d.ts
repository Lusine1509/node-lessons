export default function parseIsoDate(date: any): number;
