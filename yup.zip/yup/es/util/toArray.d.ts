export default function toArray<T>(value?: null | T | T[]): T[];
