export declare function getIn(schema: any, path: string, value: any, context?: any): {
    parent: any;
    parentPath: string;
    schema: any;
};
declare const reach: (obj: {}, path: string, value: any, context: any) => any;
export default reach;
