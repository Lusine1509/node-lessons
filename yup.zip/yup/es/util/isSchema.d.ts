import type { SchemaLike } from '../types';
declare const _default: (obj: any) => obj is SchemaLike;
export default _default;
