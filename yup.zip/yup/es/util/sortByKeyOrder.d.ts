import ValidationError from '../ValidationError';
export default function sortByKeyOrder(keys: string[]): (a: ValidationError, b: ValidationError) => number;
