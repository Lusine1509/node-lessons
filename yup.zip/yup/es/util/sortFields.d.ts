import { ObjectShape } from '../object';
export default function sortFields(fields: ObjectShape, excludes?: readonly string[]): string[];
