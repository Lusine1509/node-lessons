export default function setLocale(custom: any): void;
